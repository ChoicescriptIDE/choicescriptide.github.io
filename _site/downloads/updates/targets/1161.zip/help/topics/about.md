## About

The Choicescript IDE is a piece of software designed to aid people with the development of interactive novels (or games) using the ChoiceScript scripting language, developed by Dan Fabulich of Choice of Games LLC. The Choicescript IDE is a third party product developed indepedently by CJW (of the COG forums), and is maintained and supported by volunteers known as 'The CSIDE Team'. IN NO WAY is the ChoiceScript IDE officially endorsed by (or representative of) Choice of Games LLC. ChoiceScript is (c) Dan Fabulich.

If you have anything you want to say or ask about the application, please see the discussion thread below on the official Choice of Games forums.

If you've got a bug report, suggestion or even a complaint, feel free to post them there. You can also send us an email directly via the
provided address.

**[ChoiceScript IDE Forum Thread](http://www.choiceofgames.com/forum/discussion/2796/tool-choicescript-development-environment "ChoiceScript IDE Forum Thread")**

**cside@mazdrak.com**

### Like What You See?

Please help us spread the word about Choicescript, Choice of Games and the Choicescript IDE.

[Tweet #Choicescript](https://twitter.com/intent/tweet?button_hashtag=Choicescript&text=Make%20your%20own%20CYOA%20game%20with%20the%20Choicescript%20IDE%20and "Tweet ChoiceScript - ChoiceScript IDE")
