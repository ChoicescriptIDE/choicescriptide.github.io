## Scenes

This topic assumes basic Choicescript knowledge of Scenes and only discusses them in an IDE context.
For more general information on the topic please see the <a href="http://choicescriptdev.wikia.com/wiki/Scenes" rel="external">wiki page</a>.

### What is a Scene?

A choicescript game is usually split up into scenes, otherwise known as 'vignettes' or chapters.

Each scene's code and text is kept in its own separate text (.txt) file.

