## Terms and Conditions

CAREFULLY READ THE FOLLOWING TERMS AND CONDITIONS BEFORE USING THIS SOFTWARE. BY USING THIS FREEWARE VERSION, YOU ACKNOWLEDGE THAT YOU HAVE READ THIS LIMITED WARRANTY, UNDERSTAND IT, AND AGREE TO BE BOUND BY ITS TERMS AND CONDITIONS. YOU ALSO AGREE THAT UNLESS YOU HAVE A DIFFERENT LICENSE AGREEMENT SIGNED BY CAREY J. WILLIAMS, YOUR USE OF THIS SOFTWARE INDICATES YOUR ACCEPTANCE OF THIS LICENSE AGREEMENT AND WARRANTY. IF YOU DO NOT AGREE TO THE TERMS OF THIS AGREEMENT, DELETE THE SOFTWARE FROM ALL STORAGE MEDIA.

### License

This Freeware License Agreement (the "Agreement") is a legal agreement between you (the "Licensee"), the end-user, and Carey J. Williams (the "Author") for the free use of this software product (the "Software"). Commercial as well as non-commercial use is allowed. By using this Software or storing this program or parts of it on a computer hard drive or other media you agree to be bound by the terms of this Agreement. You may not alter this Software in any way. You may not modify, rent, or sell this Software, or create derivative works based upon this Software.

### Governing Law

This agreement shall be governed by the laws of Great Britain. If any portion of this Agreement is deemed unenforceable by a court of competent jurisdiction, it shall not affect the enforceability of any other portion of this Agreement.

### Limited Warranty and Disclaimer of Warranty

THE AUTHOR EXPRESSLY DISCLAIMS ANY WARRANTY FOR THE SOFTWARE. THIS SOFTWARE AND THE ACCOMPANYING FILES ARE PROVIDED "AS IS" AND WITHOUT WARRANTIES AS TO PERFORMANCE OR ANY OTHER WARRANTIES WHETHER EXPRESSED OR IMPLIED.

In no event shall the Author be liable for any consequential, incidental, or indirect damages whatsoever (including, without limitation, damages for loss of business profits, business interruption, loss of business information, or any other pecuniary loss) resulting from the use of or inability to use this software, even if the Author has been advised of the possibility of such damages. The entire risk resulting of use or performance of the software remains with the Licensee.